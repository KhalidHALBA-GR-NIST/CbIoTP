package IoTCapabilityPlatform.CapabilityManager;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.util.JSONPObject;
/**
 * Hello world!
 *
 */
public class CapabilityManager extends AbstractVerticle {
	    private final String url = "jdbc:postgresql://localhost/knh6";
	    private final String user = "postgres";
	    private final String password = "root1234";
	    Statement stmt = null;
	    JsonObject capability = new JsonObject();

    @Override
    public void start() throws Exception {

        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
        //    System.out.println("Connected to the PostgreSQL server successfully.");
            
            stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery( "SELECT * FROM caplist;" );
 

            JSONArray array= new JSONArray();
            
            JSONArray jsonArray = new JSONArray();
            
            JSONObject jsonobject = new JSONObject();
        //    System.out.println("Y: jsonArray2" +jsonArray2);
           
            while (resultSet.next()) {
            	
            	//System.out.println("row out " +resultSet.getRow());
            	JSONObject jsonobject1 = new JSONObject();
                for (int i = 0; i < resultSet.getMetaData().getColumnCount() ; i++) {
                	
                	//System.out.println("row in " +resultSet.getRow());
                	
                    //	System.out.println("elements" + resultSet.getObject(i + 1));
                  // 	System.out.println(" column " +i);
                	jsonobject1.put(resultSet.getMetaData().getColumnLabel(i + 1),resultSet.getObject(i + 1));
                	
                	
                	// System.out.println("resultSet.getMetaData().getColumnLabel("+i + 1+")" +resultSet.getMetaData().getColumnLabel(i + 1)+" resultSet.getObject("+i + 1+")"+resultSet.getObject(i + 1));
                	
                    if(i==2) {
                 //   System.out.println("jsonobject" +jsonobject);
                    	array.put(jsonobject1);
                    
                    System.out.println("array" +array);
                 //   System.out.println("A: jsonArray2" +jsonArray2);
                    }
                //    System.out.println("B: jsonArray2" +jsonArray2);
                }
             //   System.out.println("C: jsonArray2" +jsonArray2);
            }
            
            
            
            
            System.out.println("array 2" +array);
                vertx.createHttpServer().requestHandler(req -> {
                    req.response().end(array.toString());	
                  }).listen(8080, listenResult -> {
                    if (listenResult.failed()) {
                      listenResult.cause().printStackTrace();
                    } else {
                    }
                  }); 
        resultSet.close();
             stmt.close();
             conn.close();
             
             
        } catch (SQLException e) {
           // System.out.println(e.getMessage());
        }
    }  
    public static void main( String[] args )
    {
    	Runner.runExample(CapabilityManager.class);		
    }
}