package IoTCapabilityPlatform.CapabilityManager;
import io.vertx.core.AbstractVerticle;
import org.json.JSONException;
import org.json.JSONObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * Hello world!
 *
 */
public class CapabilityManager extends AbstractVerticle {
	    private final String url = "jdbc:postgresql://localhost/knh6";
	    private final String user = "postgres";
	    private final String password = "root1234";
	    
	    Statement stmt = null;
	    
	    
	    public Connection connect() {
	        Connection conn = null;
	        try {
	            conn = DriverManager.getConnection(url, user, password);
	            System.out.println("Connected to the PostgreSQL server successfully.");
	            
	            stmt = conn.createStatement();
	            ResultSet rs = stmt.executeQuery( "SELECT * FROM caplist;" );
	            
	            
	            while ( rs.next() ) {
	                int id = rs.getInt("id");
	                String  name = rs.getString("name");
	                String location  = rs.getString("location");
	               
	                System.out.println( "ID = " + id );
	                System.out.println( "NAME = " + name );
	                System.out.println( "LOCATION = " + location );

	                System.out.println();
	             }
	             rs.close();
	             stmt.close();
	             conn.close();
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	        return conn;
	    }
    @Override
    public void start() throws Exception {
        JSONObject capability = new JSONObject();
        capability.put("id", "1");
        capability.put("name", "tempersture");
        capability.put("location", "192.168.1.240:10010" );
      vertx.createHttpServer().requestHandler(req -> {

        req.response().end(capability.toString());

      }).listen(8080, listenResult -> {
        if (listenResult.failed()) {
          System.out.println("Could not start HTTP server");
          listenResult.cause().printStackTrace();
        } else {
          System.out.println("Capability Manager Started");
        }
      });
    }  
    public static void main( String[] args )
    {
    	CapabilityManager capabilityManager = new CapabilityManager();
    	capabilityManager.connect();
    	Runner.runExample(CapabilityManager.class);		
    }
}