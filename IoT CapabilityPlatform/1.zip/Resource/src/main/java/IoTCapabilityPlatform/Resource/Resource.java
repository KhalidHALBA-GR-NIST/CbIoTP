package IoTCapabilityPlatform.Resource;

/**
 * Hello world!
 *
 */
public class Resource 
{
	
	
	
	
	
	
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}


//public void start() {
//getLogger().info("Broadcaster started");
//vertx.setPeriodic(PERIOD_MS, timerID -> {
//getLogger().info("Broadcasting message " + counter);
//vertx.eventBus().send(Consumer.CONSUMER_ADDRESS,
//"Message " + counter);
//counter++;
//});
//}